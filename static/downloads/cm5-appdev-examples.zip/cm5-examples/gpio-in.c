#include <stdlib.h>
#include <gpiod.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdbool.h>

static volatile sig_atomic_t running = 1;
void sig_handler(int sig) { running = 0; }

int main(void)
{
    const char *chip_name = getenv("CM5_GPIO_CHIP");
    if (!chip_name) { fputs("Set CM5_GPIO_CHIP first\n", stderr); return 1; }
    const unsigned int ext_offset = 14;   /* GPIO0_B6 扩展排针 */
    const unsigned int key_offset = 0;    /* GPIO0_A0 按键 */

    struct gpiod_chip *chip;
    struct gpiod_line *ext, *key;

    /* 捕获 Ctrl+C */
    signal(SIGINT, sig_handler);

    /* 打开 gpiochip0 */
    chip = gpiod_chip_open_by_name(chip_name);
    if (!chip) { perror("open chip"); return 1; }

    /* 排针：输出，默认高 */
    ext = gpiod_chip_get_line(chip, ext_offset);
    if (!ext || gpiod_line_request_output(ext, "ext_pin", 1) < 0) {
        perror("request ext"); gpiod_chip_close(chip); return 1;
    }

    /* 按键：输入，下降沿中断 */
    key = gpiod_chip_get_line(chip, key_offset);
    if (!key || gpiod_line_request_falling_edge_events(key, "btn") < 0) {
        perror("request key"); gpiod_chip_close(chip); return 1;
    }

    puts("扩展排针 GPIO0_B6 默认为高");
    puts("按下 GPIO0_A0 时 GPIO0_B6 拉低，松开恢复高");
    puts("Ctrl+C 退出");

    while (running) {
        if (gpiod_line_event_wait(key, NULL) == 1) {   /* 等到下降沿 */
            struct gpiod_line_event ev;
            gpiod_line_event_read(key, &ev);           /* 清事件 */

            gpiod_line_set_value(ext, 0);              /* 拉低 */
            puts("按键按下 → GPIO0_B6 = 低");

            /* 等待松开（防抖） */
            while (gpiod_line_get_value(key) == 0 && running)
                usleep(10000);                         /* 10 ms */

            gpiod_line_set_value(ext, 1);              /* 恢复高 */
            puts("按键松开 → GPIO0_B6 = 高");
        }
    }

    /* 释放资源 */
    gpiod_line_release(ext);
    gpiod_line_release(key);
    gpiod_chip_close(chip);
    puts("结束");
    return 0;
}
