#!/usr/bin/env python3
from camera import open_camera
import cv2
import numpy as np

# Open the configured capture source
cap = open_camera()
if not cap.isOpened():
    raise RuntimeError("Cannot open camera")

# optional resolution

# Hough parameters
rho_res   = 1          # pixel resolution
theta_res = np.pi/180  # radian resolution
thresh    = 80         # accumulator threshold
min_len   = 50         # minimum line length
max_gap   = 10         # maximum gap between segments

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 1. grayscale + blur
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)

    # 2. Canny edge map
    edges = cv2.Canny(blur, 50, 150)

    # 3. Probabilistic Hough Transform
    lines = cv2.HoughLinesP(edges,
                            rho_res,
                            theta_res,
                            threshold=thresh,
                            minLineLength=min_len,
                            maxLineGap=max_gap)

    # 4. draw lines on copy of original frame
    display = frame.copy()
    if lines is not None:
        for x1, y1, x2, y2 in lines[:, 0]:
            cv2.line(display, (x1, y1), (x2, y2), (0, 255, 0), 2)

    # 5. show result
    print("processed:", display.shape)
    cv2.imshow("Hough Line Detection (USB)", display)

    # 6. exit on 'q' or ESC
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):
        break

# cleanup
cap.release()
cv2.destroyAllWindows()
