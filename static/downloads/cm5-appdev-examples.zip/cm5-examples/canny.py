#!/usr/bin/env python3
from camera import open_camera
import cv2

# Open the configured capture source
cap = open_camera()
if not cap.isOpened():
    raise RuntimeError("Cannot open camera; check connection or permissions")

# Optional: set resolution

# Canny thresholds
low_th  = 100
high_th = 200

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 1. Convert to grayscale and apply Gaussian blur
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)

    # 2. Canny edge detection
    edges = cv2.Canny(blur, low_th, high_th)

    # 3. Convert single-channel edge map back to 3-channel for display
    edges_bgr = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

    # 4. Concatenate original and edge images side by side
    combined = cv2.hconcat([frame, edges_bgr])
    print("processed:", combined.shape)
    cv2.imshow("USB Canny (left: original, right: edges)", combined)

    # 5. Exit on 'q' or ESC
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()
