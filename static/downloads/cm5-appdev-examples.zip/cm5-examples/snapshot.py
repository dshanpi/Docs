import cv2
from camera import open_camera
cap = open_camera()

if not cap.isOpened():
    raise RuntimeError("无法打开摄像头")

ret, frame = cap.read()
if ret:
    if not cv2.imwrite("frame.jpg", frame):
        raise OSError("写入 frame.jpg 失败")
    print("保存 frame.jpg 成功")
else:
    raise RuntimeError("读取失败")

cap.release()
