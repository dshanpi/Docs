#include <QApplication>
#include <QDebug>
#include <QTimer>
#include "ui_mainwindow.h"

int main(int argc, char **argv) {
    QApplication app(argc, argv);
    QMainWindow window;
    Ui::MainWindow ui;
    ui.setupUi(&window);
    window.show();
    qInfo().noquote() << "label:" << ui.label->text();
    if (app.arguments().contains("--check"))
        QTimer::singleShot(400, &app, &QApplication::quit);
    return app.exec();
}
