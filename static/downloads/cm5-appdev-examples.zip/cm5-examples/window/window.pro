QT += widgets
SOURCES += main.cpp
FORMS += mainwindow.ui
TARGET = cm5-ui
