import os
import pty
import select
import subprocess

master, slave = pty.openpty()
node = os.ttyname(slave)
proc = subprocess.Popen(["stdbuf", "-oL", "./serial_send_recv", node],
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE)
try:
    proc.stdin.write(b"A")
    proc.stdin.flush()
    if not select.select([master], [], [], 5)[0]:
        raise RuntimeError("TX timed out")
    sent = os.read(master, 1)
    assert sent == b"A", sent
    os.write(master, sent)
    if not select.select([proc.stdout], [], [], 5)[0]:
        raise RuntimeError("RX timed out")
    reply = proc.stdout.readline().decode().strip()
    print(reply)
    assert "get: 41 A" in reply
finally:
    proc.terminate()
    proc.wait()
    os.close(master)
    os.close(slave)
