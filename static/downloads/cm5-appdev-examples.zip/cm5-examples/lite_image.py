import numpy as np
from rknnlite.api import RKNNLite


class RKNN_model_container:
    def __init__(self, model_path, target=None, device_id=None):
        self.model = RKNNLite()
        if self.model.load_rknn(model_path) != 0 or self.model.init_runtime() != 0:
            raise RuntimeError(f"Cannot initialize {model_path}")

    def run(self, inputs):
        batch = [image[None, ...] if image.ndim == 3 else image for image in inputs]
        outputs = self.model.inference(inputs=batch)
        if outputs is None:
            raise RuntimeError("Inference failed")
        return outputs

    def release(self):
        self.model.release()
