#!/bin/bash
set -eu

src=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
cd "$work"
if [[ -d /sys/module/gpio_mockup ]]; then
    echo "已有 gpio-mockup 控制器，请先结束占用它的实验。" >&2
    exit 1
fi
modprobe gpio-mockup gpio_mockup_ranges=-1,20
child=
exported=
cleanup() {
    if [[ -n "$child" ]]; then kill "$child" 2>/dev/null || true; wait "$child" || true; fi
    if [[ -n "$exported" ]]; then echo "$exported" > /sys/class/gpio/unexport; fi
    modprobe -r gpio_mockup
}
trap cleanup EXIT
CM5_GPIO_CHIP=$(gpiodetect | awk '/gpio-mockup/{print $1; exit}')
export CM5_GPIO_CHIP
test -n "$CM5_GPIO_CHIP"
pins=/sys/kernel/debug/gpio-mockup/$CM5_GPIO_CHIP
test -e "$pins/0"
stop_example() {
    kill "$child"
    wait "$child" || true
    child=
}

gcc "$src/gpio-out.c" -o gpio-out -lgpiod
gcc "$src/gpio-in.c" -o gpio-in -lgpiod
for lang in py c; do
    if [[ "$lang" == py ]]; then
        output=(/usr/bin/python3 -u "$src/gpio-out.py")
        input=(/usr/bin/python3 -u "$src/gpio-in.py")
    else
        output=(./gpio-out)
        input=(./gpio-in)
    fi
    "${output[@]}" >"output-$lang.log" 2>&1 &
    child=$!
    sleep 0.2
    echo "$lang output: $(cat "$pins/14")"
    sleep 0.5
    echo "$lang output: $(cat "$pins/14")"
    stop_example

    echo 1 > "$pins/0"
    stdbuf -oL "${input[@]}" >"input-$lang.log" 2>&1 &
    child=$!
    sleep 0.5
    echo 0 > "$pins/0"
    sleep 0.4
    echo 1 > "$pins/0"
    sleep 0.4
    stop_example
    cat "input-$lang.log"
    grep -q '按键按下 →' "input-$lang.log"
    grep -q '按键松开 →' "input-$lang.log"
done

for chip in /sys/class/gpio/gpiochip*; do
    if [[ $(cat "$chip/label") == gpio-mockup* ]]; then
        base=$(cat "$chip/base")
        break
    fi
done
number=$((base + 14))
echo "$number" > /sys/class/gpio/export
exported=$number
pin=/sys/class/gpio/gpio$number
echo in > "$pin/direction"
cat "$pin/value"
echo out > "$pin/direction"
for value in 1 0; do
    echo "$value" > "$pin/value"
    cat "$pin/value"
done
