import os

import cv2


def open_camera():
    path = os.environ.get("CM5_IMAGE")
    if path:
        class SingleFrame:
            def __init__(self):
                self.image = cv2.imread(path)
                if self.image is None:
                    raise FileNotFoundError(path)
            def isOpened(self):
                return self.image is not None
            def read(self):
                image, self.image = self.image, None
                return image is not None, image
            def release(self):
                self.image = None
        return SingleFrame()
    device = os.environ.get("CM5_CAMERA", "/dev/video42")
    pipeline = (f"v4l2src device={device} num-buffers=3 ! "
                "videoconvert ! videoscale ! video/x-raw,format=BGR,width=640,height=480 ! appsink")
    return cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
