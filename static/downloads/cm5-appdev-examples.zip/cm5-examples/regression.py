#!/usr/bin/env python3
from camera import open_camera
import cv2
import numpy as np

# ---------- camera ----------
cap = open_camera()
if not cap.isOpened():
    raise RuntimeError("Cannot open camera")

# ---------- parameters ----------
CANNY_LOW   = 50
CANNY_HIGH  = 150
HOUGH_RHO   = 1
HOUGH_THETA = np.pi / 180
HOUGH_TH    = 100            # Hough threshold
MIN_LINE    = 50             # minLineLength
MAX_GAP     = 10             # maxLineGap
DRAW_COLOR  = (0, 255, 0)
DRAW_THICK  = 3

def draw_regression(frame, points):
    """Fit y = kx + b with NumPy polyfit and draw the line."""
    if points.shape[0] < 2:
        return
    x, y = points[:, 0], points[:, 1]
    k, b = np.polyfit(x, y, 1)          # 1-degree polynomial = linear
    h, w = frame.shape[:2]
    x0, x1 = 0, w
    y0, y1 = int(k * x0 + b), int(k * x1 + b)
    cv2.line(frame, (x0, y0), (x1, y1), DRAW_COLOR, DRAW_THICK)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, CANNY_LOW, CANNY_HIGH)

    # Hough line segments
    lines = cv2.HoughLinesP(edges,
                            HOUGH_RHO,
                            HOUGH_THETA,
                            HOUGH_TH,
                            minLineLength=MIN_LINE,
                            maxLineGap=MAX_GAP)

    # collect endpoints
    pts = []
    if lines is not None:
        for x1, y1, x2, y2 in lines[:, 0]:
            pts.extend([[x1, y1], [x2, y2]])

    if pts:
        pts = np.array(pts, dtype=np.float32)
        draw_regression(frame, pts)

    print("processed:", frame.shape)
    cv2.imshow("USB Line Regression", frame)
    if cv2.waitKey(1) & 0xFF in (27, ord('q')):
        break

cap.release()
cv2.destroyAllWindows()
