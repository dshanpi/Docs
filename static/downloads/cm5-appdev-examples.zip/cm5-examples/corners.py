#!/usr/bin/env python3
from camera import open_camera
import cv2
import numpy as np

# ---------- open camera ----------
cap = open_camera()   # change index if needed
if not cap.isOpened():
    raise RuntimeError("Cannot open camera")

# optional resolution

# ---------- Harris parameters ----------
HARRIS_BLOCK_SIZE = 2          # neighbourhood size
HARRIS_KSIZE      = 3          # Sobel aperture
HARRIS_K          = 0.04       # Harris detector free parameter
THRESH_RATIO      = 0.01       # corner response threshold ratio

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # ---------- Harris corner detection ----------
    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray  = np.float32(gray)
    dst   = cv2.cornerHarris(gray,
                             blockSize=HARRIS_BLOCK_SIZE,
                             ksize=HARRIS_KSIZE,
                             k=HARRIS_K)
    # dilate corners for better visibility
    dst = cv2.dilate(dst, None)

    # threshold corner response
    frame[dst > THRESH_RATIO * dst.max()] = [0, 0, 255]

    # ---------- show ----------
    print("processed:", frame.shape)
    cv2.imshow("Harris Corner Detection (USB)", frame)

    # quit on 'q' or ESC
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):
        break

# ---------- cleanup ----------
cap.release()
cv2.destroyAllWindows()
