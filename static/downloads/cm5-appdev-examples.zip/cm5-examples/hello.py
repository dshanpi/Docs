import cv2, sys, numpy as np
print("OpenCV Version:", cv2.__version__)
print("Python Version:", sys.version.split()[0])

img = np.full((400,400,3), (255,0,0), dtype=np.uint8)  # BGR Blue
cv2.imshow("OpenCV Test", img)
cv2.waitKey(3000)
cv2.destroyAllWindows()
print("OpenCV Ready！")
