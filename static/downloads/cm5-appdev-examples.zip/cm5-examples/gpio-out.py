import os
#!/usr/bin/env python3
import gpiod
import time

CHIP_NAME   = os.environ["CM5_GPIO_CHIP"]     # /dev/gpiochip0
LINE_OFFSET = 14          # GPIO0_B6

chip = gpiod.Chip(CHIP_NAME)
line = chip.get_line(LINE_OFFSET)

# 申请为输出，默认低电平
line.request(consumer="rk3576-gpio", type=gpiod.LINE_REQ_DIR_OUT, default_vals=[0])

try:
    while True:
        line.set_value(1)
        time.sleep(0.5)
        line.set_value(0)
        time.sleep(0.5)
except KeyboardInterrupt:
    pass
finally:
    line.release()
