from itertools import groupby

predictions = ["湘", "湘", None, "F", None, "F"]
plate = "".join(char for char, _ in groupby(predictions) if char is not None)
print(plate)  # 湘FF
