import os
#!/usr/bin/env python3
import gpiod
import time

# gpio0 芯片
chip  = gpiod.Chip(os.environ["CM5_GPIO_CHIP"])
# 输出脚：GPIO0_B6 (offset 14)
led   = chip.get_line(14)
# 输入脚：GPIO0_A0 (offset 0)
btn   = chip.get_line(0)

# 申请输出，默认高
led.request(consumer="led",
            type=gpiod.LINE_REQ_DIR_OUT,
            default_vals=[1])

# 申请输入，启用下降沿中断
btn.request(consumer="btn",
            type=gpiod.LINE_REQ_EV_FALLING_EDGE)

print("上电：GPIO0_B6 = 高")
print("按下 GPIO0_A0 后：GPIO0_B6 拉低，松开恢复高")
print("Ctrl+C 退出")

try:
    while True:
        ev = btn.event_wait(sec=1)   # 阻塞等 1 秒
        if ev and btn.event_read().type == gpiod.LineEvent.FALLING_EDGE:
            led.set_value(0)         # 按下 -> 低
            print("按键按下 → GPIO0_B6 = 低")
            # 简单消抖：等待按钮松开
            while btn.get_value() == 0:
                time.sleep(0.01)
            led.set_value(1)         # 松开 -> 高
            print("按键松开 → GPIO0_B6 = 高")
except KeyboardInterrupt:
    pass
finally:
    led.release()
    btn.release()
