#!/bin/bash
set -eu
src=$(cd "$(dirname "$0")" && pwd)
cd "$(mktemp -d)"
if [[ -d /sys/module/i2c_stub ]]; then
    echo "已有 i2c-stub 总线，请先结束占用它的实验。" >&2
    exit 1
fi
modprobe i2c-stub chip_addr=0x68
trap 'modprobe -r i2c_stub' EXIT
CM5_I2C_BUS=$(i2cdetect -l | awk '/SMBus stub/{sub("i2c-","",$1); print $1; exit}')
test -n "$CM5_I2C_BUS"
export CM5_I2C_BUS
export CM5_I2C_DEV="/dev/i2c-$CM5_I2C_BUS"
i2cdetect -l | grep stub
/usr/bin/python3 "$src/i2c.py"
gcc -Wall "$src/i2c_test.c" -o i2c_test
if ! ./i2c_test; then
    i2cdetect -F "$CM5_I2C_BUS" | head -4
fi
if [[ -f /sys/bus/i2c/devices/4-0011/name ]]; then
    cat /sys/bus/i2c/devices/4-0011/name
fi
