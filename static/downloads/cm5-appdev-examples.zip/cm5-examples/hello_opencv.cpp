#include <opencv2/opencv.hpp>

int main()
{
    // 画布尺寸
    int width = 400, height = 200;

    // 创建蓝色背景 (BGR)
    cv::Mat img(height, width, CV_8UC3, cv::Scalar(255, 0, 0));

    // 配置文字
    std::string text = "Hello OpenCV";
    int fontFace = cv::FONT_HERSHEY_SIMPLEX;
    double fontScale = 1.0;
    int thickness = 2;

    // 计算文字大小，使文字居中
    int baseline = 0;
    cv::Size textSize = cv::getTextSize(text, fontFace, fontScale, thickness, &baseline);
    cv::Point org((width - textSize.width) / 2,
                  (height + textSize.height) / 2);

    // 绘制文字（白色）
    cv::putText(img, text, org, fontFace, fontScale,
                cv::Scalar(255, 255, 255), thickness, cv::LINE_AA);

    // 保存到磁盘
    cv::imwrite("hello_opencv.jpg", img);

    cv::imshow("Hello", img);
    cv::waitKey(3000);

    return 0;
}
