#!/usr/bin/env python3
from camera import open_camera
import cv2

# 0. 打开摄像头
cap = open_camera()
if not cap.isOpened():
    raise RuntimeError("Cannot open camera")

# 1. 加载 Haar 人脸模型（已随 OpenCV 安装）
face_cascade = cv2.CascadeClassifier('/usr/share/opencv4/haarcascades/' +
                                     'haarcascade_frontalface_default.xml')

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 2. 灰度化 + 检测
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray,
                                          scaleFactor=1.1,
                                          minNeighbors=5,
                                          minSize=(50, 50))

    # 3. 画框
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h),
                      (0, 255, 0), 2)

    # 4. 显示
    print("processed:", frame.shape)
    cv2.imshow("USB Face Detection", frame)
    if cv2.waitKey(1) & 0xFF in (27, ord('q')):
        break

cap.release()
cv2.destroyAllWindows()
