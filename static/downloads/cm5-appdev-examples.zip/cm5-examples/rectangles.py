#!/usr/bin/env python3
from camera import open_camera
import cv2
import numpy as np

# ------------ camera setup ------------
cap = open_camera() 
if not cap.isOpened():
    raise RuntimeError("Cannot open camera")


# ------------ parameters ------------
# Canny thresholds
CANNY_LOW  = 50
CANNY_HIGH = 150
# contour approximation accuracy (epsilon = arcLength * ratio)
APPROX_RATIO = 0.02
# min area filter (ignore tiny noise)
MIN_AREA = 500

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # ---------- pre-processing ----------
    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, CANNY_LOW, CANNY_HIGH)

    # ---------- find contours ----------
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)

    # ---------- loop over contours ----------
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < MIN_AREA:
            continue

        # polygonal approximation
        epsilon = APPROX_RATIO * cv2.arcLength(cnt, True)
        approx  = cv2.approxPolyDP(cnt, epsilon, True)

        # we need 4 vertices => rectangle
        if len(approx) == 4:
            cv2.drawContours(frame, [approx], -1, (0, 255, 0), 2)

    # ---------- display ----------
    print("processed:", frame.shape)
    cv2.imshow("Real-time Rectangle Detection", frame)

    # quit on 'q' or ESC
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):
        break

# ---------- cleanup ----------
cap.release()
cv2.destroyAllWindows()
