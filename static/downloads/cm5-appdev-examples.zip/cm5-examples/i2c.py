import os
import smbus

DEVICE_ADDR   = 0x68   # 从机地址
REGISTER_ADDR = 0x01   # 要读写的寄存器地址

# 打开 I2C 总线 2 (/dev/i2c-2)
bus = smbus.SMBus(int(os.environ["CM5_I2C_BUS"]))

# 写寄存器：向 0x01 写入 0x55
bus.write_byte_data(DEVICE_ADDR, REGISTER_ADDR, 0x55)
print("已写入 0x55")

# 读寄存器：从 0x01 读取 1 个字节
value = bus.read_byte_data(DEVICE_ADDR, REGISTER_ADDR)
print(f"寄存器 0x{REGISTER_ADDR:02X} 的值 = 0x{value:02X}")

# 关闭总线
bus.close()
