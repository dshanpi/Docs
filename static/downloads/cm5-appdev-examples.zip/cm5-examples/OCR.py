import os
import sys
from camera import open_camera
import cv2
import copy
import numpy as np
import argparse
import ppocr_rec as predict_rec
import ppocr_det as predict_det

os.environ["FLAGS_allocator_strategy"] = 'auto_growth'

DET_INPUT_SHAPE = [480, 480]  # h,w


class TextSystem(object):
    def __init__(self, args):
        self.text_detector = predict_det.TextDetector(args)
        self.text_recognizer = predict_rec.TextRecognizer(args)
        self.drop_score = 0.5

    def run(self, img):
        ori_im = img.copy()
        dt_boxes = self.text_detector.run(img)
        if dt_boxes is None or len(dt_boxes) == 0:
            return [], []

        img_crop_list = []
        dt_boxes = sorted_boxes(dt_boxes)
        for box in dt_boxes:
            img_crop = get_rotate_crop_image(ori_im, box)
            img_crop_list.append(img_crop)

        rec_res = self.text_recognizer.run(img_crop_list)
        rec_res = [prediction[0] for prediction in rec_res]

        filter_boxes, filter_rec_res = [], []
        for box, (text, score) in zip(dt_boxes, rec_res):
            if score >= self.drop_score:
                filter_boxes.append(box)
                filter_rec_res.append((text, score))
        return filter_boxes, filter_rec_res

def get_rotate_crop_image(img, points):
    assert len(points) == 4, "shape of points must be 4*2"
    img_crop_width = int(
        max(np.linalg.norm(points[0] - points[1]),
            np.linalg.norm(points[2] - points[3])))
    img_crop_height = int(
        max(np.linalg.norm(points[0] - points[3]),
            np.linalg.norm(points[1] - points[2])))
    pts_std = np.float32([[0, 0], [img_crop_width, 0],
                          [img_crop_width, img_crop_height],
                          [0, img_crop_height]])
    M = cv2.getPerspectiveTransform(points, pts_std)
    dst_img = cv2.warpPerspective(
        img, M, (img_crop_width, img_crop_height),
        borderMode=cv2.BORDER_REPLICATE, flags=cv2.INTER_CUBIC)
    if dst_img.shape[0] / dst_img.shape[1] >= 1.5:
        dst_img = np.rot90(dst_img)
    return dst_img


def sorted_boxes(dt_boxes):
    num_boxes = dt_boxes.shape[0]
    sorted_boxes = sorted(dt_boxes, key=lambda x: (x[0][1], x[0][0]))
    _boxes = list(sorted_boxes)
    for i in range(num_boxes - 1):
        for j in range(i, -1, -1):
            if abs(_boxes[j + 1][0][1] - _boxes[j][0][1]) < 10 and \
                    (_boxes[j + 1][0][0] < _boxes[j][0][0]):
                _boxes[j], _boxes[j + 1] = _boxes[j + 1], _boxes[j]
            else:
                break
    return _boxes


def init_args():
    parser = argparse.ArgumentParser(description='PPOCR-System Camera Demo')
    parser.add_argument('--det_model_path', type=str, required=True)
    parser.add_argument('--rec_model_path', type=str, required=True)
    parser.add_argument('--target', type=str, default='rk3566')
    parser.add_argument('--device_id', type=str, default=None)
    return parser


def draw_ocr_box_txt(img, boxes, rec_res):
    for (box, (txt, score)) in zip(boxes, rec_res):
        box = np.array(box).astype(np.int32)
        cv2.polylines(img, [box], True, (0, 255, 0), 2)
        label = f"{txt}"
        left, top = box[0]
        cv2.putText(img, label, (left, top - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
    return img


if __name__ == '__main__':
    parser = init_args()
    args = parser.parse_args()
    system_model = TextSystem(args)

    cap = open_camera()                  # 打开摄像头
    if not cap.isOpened():
        sys.exit("Cannot open camera 0")

    print("Press 'q' to quit")
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        img = cv2.resize(frame, (DET_INPUT_SHAPE[1], DET_INPUT_SHAPE[0]))
        boxes, rec_res = system_model.run(img)

        vis = draw_ocr_box_txt(img, boxes, rec_res)
        print("recognized:", [(text, round(float(score), 3)) for text, score in rec_res])
        print("processed:", vis.shape)
        cv2.imshow("PPOCR-System", vis)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
