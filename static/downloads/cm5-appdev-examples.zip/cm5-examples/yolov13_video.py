import sys
from pathlib import Path
import cv2
import numpy as np
from rknnlite.api import RKNNLite
from camera import open_camera

def draw(image, outputs):
    assert len(outputs) == 6
    boxes, scores, classes = [], [], []
    for loc, cls in zip(outputs[::2], outputs[1::2]):
        _, _, h, w = loc.shape
        dist = loc[0].astype(np.float32).reshape(4, 16, h, w)
        weights = np.exp(dist - dist.max(axis=1, keepdims=True))
        dist = (weights * np.arange(16)[None, :, None, None]).sum(axis=1) / weights.sum(axis=1)
        cls = cls[0].astype(np.float32)
        labels = cls.argmax(axis=0)
        prob = 1 / (1 + np.exp(-np.clip(cls.max(axis=0), -60, 60)))
        for y, x in zip(*np.where(prob >= 0.5)):
            left, top, right, bottom = dist[:, y, x] * (640 / w)
            cx, cy = (x + 0.5) * 640 / w, (y + 0.5) * 640 / h
            boxes.append([float(cx-left), float(cy-top), float(left+right), float(top+bottom)])
            scores.append(float(prob[y, x]))
            classes.append(int(labels[y, x]))
    with open(Path(__file__).with_name("coco_80_labels_list.txt")) as f:
        names = f.read().splitlines()
    for label in sorted(set(classes)):
        ids = [i for i, c in enumerate(classes) if c == label]
        keep = cv2.dnn.NMSBoxes([boxes[i] for i in ids], [scores[i] for i in ids], 0.5, 0.45)
        for k in np.asarray(keep).flatten():
            i = ids[k]
            x, y, w, h = boxes[i]
            p, q = (round(x), round(y)), (round(x+w), round(y+h))
            print(names[label], round(scores[i], 3), p, q)
            cv2.rectangle(image, p, q, (0, 255, 0), 2)
            cv2.putText(image, names[label], p, cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

cap = open_camera()
if not cap.isOpened():
    raise RuntimeError("Camera did not open")
npu = RKNNLite()
if npu.load_rknn(sys.argv[1]) or npu.init_runtime():
    raise RuntimeError("RKNN initialization failed")
try:
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        image = cv2.resize(frame, (640, 640))
        outputs = npu.inference(inputs=[cv2.cvtColor(image, cv2.COLOR_BGR2RGB)[None, ...]])
        draw(image, outputs)
        print("output heads:", len(outputs))
        cv2.imshow("YOLOv13", image)
        if cv2.waitKey(1) == ord("q"):
            break
finally:
    cap.release()
    npu.release()
    cv2.destroyAllWindows()
