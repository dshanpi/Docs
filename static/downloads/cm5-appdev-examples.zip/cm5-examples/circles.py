#!/usr/bin/env python3
from camera import open_camera
import cv2
import numpy as np

# camera configuration
SENSOR_W, SENSOR_H = 640,480   # GStreamer output size
FRAME_W, FRAME_H   = 320, 240    # processing / display resolution

# open camera 0 and set native resolution
cap = open_camera()

if not cap.isOpened():
    raise RuntimeError("Cannot open camera")

print(f"Camera configured: capture {SENSOR_W}x{SENSOR_H} → process {FRAME_W}x{FRAME_H}")

# scale factor for parameter adaptation
SCALE_FACTOR = max(SENSOR_W / FRAME_W, SENSOR_H / FRAME_H)

while True:
    # grab full-resolution frame
    ret, frame_high_res = cap.read()
    if not ret:
        break

    # down-scale for processing
    frame = cv2.resize(frame_high_res, (FRAME_W, FRAME_H))

    # grayscale + blur
    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur  = cv2.GaussianBlur(gray, (9, 9), 2)

    # adapt detection parameters according to scale
    min_dist_scaled   = max(20, int(50  / SCALE_FACTOR))
    min_radius_scaled = max(5,  int(10  / SCALE_FACTOR))
    max_radius_scaled = min(100,int(100 / SCALE_FACTOR))

    # detect circles via Hough transform
    circles = cv2.HoughCircles(
        blur,
        cv2.HOUGH_GRADIENT,
        dp=1,
        minDist=min_dist_scaled,
        param1=50,
        param2=30,
        minRadius=min_radius_scaled,
        maxRadius=max_radius_scaled
    )

    # draw detected circles on the high-resolution frame
    if circles is not None:
        circles = np.uint16(np.around(circles))
        for x, y, r in circles[0, :]:
            # map coordinates back to high-resolution space
            x_hr = int(x * SCALE_FACTOR)
            y_hr = int(y * SCALE_FACTOR)
            r_hr = int(r * SCALE_FACTOR)

            # draw circle and center
            cv2.circle(frame_high_res, (x_hr, y_hr), r_hr, (0, 255, 0), 3)
            cv2.circle(frame_high_res, (x_hr, y_hr), 3,   (0, 0, 255), 5)

    # overlay resolution info
    cv2.putText(frame_high_res,
                f"Sensor: {SENSOR_W}x{SENSOR_H} | Display: {FRAME_W}x{FRAME_H}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2)

    # display result
    print("processed:", frame_high_res.shape)
    cv2.imshow("Real-time Circle Detection", frame_high_res)

    # quit on 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# cleanup
cap.release()
cv2.destroyAllWindows()
