#include <stdlib.h>
#include <gpiod.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

static volatile int running = 1;
void handle_sig(int sig) { running = 0; }

int main(void)
{
    const char *chip_name = getenv("CM5_GPIO_CHIP");
    if (!chip_name) { fputs("Set CM5_GPIO_CHIP first\n", stderr); return 1; }
    const unsigned int line_offset = 14;   /* GPIO0_B6 */

    struct gpiod_chip *chip;
    struct gpiod_line *line;

    chip = gpiod_chip_open_by_name(chip_name);
    if (!chip) { perror("open chip"); return 1; }

    line = gpiod_chip_get_line(chip, line_offset);
    if (!line) { perror("get line"); gpiod_chip_close(chip); return 1; }

    /* 申请输出，默认低电平 */
    if (gpiod_line_request_output(line, "rk3576-gpio", 0) < 0) {
        perror("request output"); gpiod_chip_close(chip); return 1;
    }

    signal(SIGINT, handle_sig);   /* Ctrl+C 退出 */

    while (running) {
        gpiod_line_set_value(line, 1);
        usleep(500000);       /* 0.5 s */
        gpiod_line_set_value(line, 0);
        usleep(500000);
    }

    gpiod_line_release(line);
    gpiod_chip_close(chip);
    puts("\n结束");
    return 0;
}
