#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>

#define I2C_DEV getenv("CM5_I2C_DEV")   // I2C 总线设备节点
#define DEV_ADDR 0x68          // 从机地址

int main() {
    int fd;
    char reg = 0x01;   // 寄存器地址
    char buf[10];

    // 打开 I2C 设备
    if ((fd = open(I2C_DEV, O_RDWR)) < 0) {
        perror("打开 I2C 设备失败");
        exit(1);
    }

    // 指定从机地址
    if (ioctl(fd, I2C_SLAVE, DEV_ADDR) < 0) {
        perror("设置 I2C 从机地址失败");
        close(fd);
        exit(1);
    }

    // 写寄存器（例如：向 0x01 写入 0x55）
    buf[0] = reg;    // 寄存器地址
    buf[1] = 0x55;   // 要写的数据
    if (write(fd, buf, 2) != 2) {
        perror("写寄存器失败"); close(fd); return 1;
    } else {
        printf("已向寄存器 0x%02X 写入 0x%02X\n", reg, buf[1]);
    }

    // 读寄存器
    if (write(fd, &reg, 1) != 1) {
        perror("写寄存器地址失败"); close(fd); return 1;
    } else {
        if (read(fd, buf, 1) != 1) {
            perror("读取寄存器失败"); close(fd); return 1;
        } else {
            printf("寄存器 0x%02X 的值 = 0x%02X\n", reg, buf[0]);
        }
    }

    close(fd);
    return 0;
}
