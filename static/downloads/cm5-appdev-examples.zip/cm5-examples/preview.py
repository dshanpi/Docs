import cv2

from camera import open_camera
cap = open_camera()
if not cap.isOpened():
    print("无法打开摄像头")
    exit()

print("按 q 退出预览")
while True:
    ret, frame = cap.read()
    if not ret:
        break
    print("processed:", frame.shape)
    cv2.imshow("Camera Preview", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
